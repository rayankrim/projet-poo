package projet;

public class RacineCarre extends OperationUnaire{

	public RacineCarre(ExpressionArithmetique ea) {
		super(ea);
	}

	public String toString() {
		return "RacineCarre("+this.ea.calculer()+")";
	}
	
	public double calculer() {
		double calculRacine=Math.sqrt(this.ea.calculer());
		int cR= (int) calculRacine;
		
		if(cR*cR == this.ea.calculer())
			return calculRacine;
		else 
			return this.ea.calculer();
	}
	
	@Override
	public ExpressionArithmetique simplifie(ConstEntiere nb){
		double calculRacine=Math.sqrt(nb.getEntier());
		int cR= (int) calculRacine;
		if(cR*cR == nb.getEntier()) {
			return new ConstEntiere(cR).simplifier();
		}else {
			return this.ea;
		}
	}
	
	@Override
	public ExpressionArithmetique simplifie(ConstRationnelle nb) {
		return this.ea;
	}

	@Override
	public boolean egaliteAr(ExpressionArithmetique expr2) {
		// TODO Auto-generated method stub
		return false;
	}

}
