
public interface ExpressionArithmetique {
	public ExpressionArithmetique simplifier();
	public double calculer();
}