import static org.junit.Assert.assertEquals;
import org.junit.Test;
public class AppTest{

	@Test
	public void simpleSum() {

		ConstEntiere quatre = new ConstEntiere(5);
		RacineCarre racine = new RacineCarre(quatre);
		
		System.out.println(racine.toString());
		double r= racine.toString().parseDouble();
	//	assertEquals(2,((ConstEntiere) racine.simplifier()).getEntier());
	//	System.out.println(((ConstEntiere) racine.simplifier()).getEntier());
	//	assertEquals( 11, ((ConstEntiere) racine.simplifier()).getEntier());

	}

/*	@Test
	public void classExample() {

		ExpressionArithmetique neuf = new ConstEntiere(9);
		ExpressionArithmetique deux = new ConstEntiere(2);
		ExpressionArithmetique trois = new ConstEntiere(3);
		ExpressionArithmetique cr = new ConstRationnelle(1, 17);

		ExpressionArithmetique plus = new Addition(neuf, deux);
	//	ExpressionArithmetique minus = new Soustraction(trois, cr);
	//	ExpressionArithmetique times = new Multiplication(plus, minus);

		

	//	assertEquals(550, ((ConstRationnelle) times.simplifier()).getNumerateur());
	//	assertEquals(17, ((ConstRationnelle) times.simplifier()).getDenominateur());

	}
	
	@Test
	public void exempleCalculer() {

		ExpressionArithmetique neuf = new ConstEntiere(9);
		ExpressionArithmetique deux = new ConstEntiere(2);
		ExpressionArithmetique trois = new ConstEntiere(3);
		ExpressionArithmetique cr = new ConstRationnelle(1, 17);

		ExpressionArithmetique plus = new Addition(neuf, deux);
	//	ExpressionArithmetique minus = new Soustraction(trois, cr);
	//	ExpressionArithmetique times = new Multiplication(plus, minus);

		ExpressionArithmetique results = new ConstRationnelle(550, 17);

		
	//	assertEquals(550/17.0, times.calculer(),0.00001);

	}
	*/
}
