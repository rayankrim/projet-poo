import static org.junit.Assert.*;
import org.junit.Test;

/**
 * 
 */

/**
 * @author LNG
 *
 */
public class RacineCarreTest {

	@Test
	public final void test() {
		fail("Not yet implemented"); // TODO
	}

}
