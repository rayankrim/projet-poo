public class Essais { // NE CALCULEZ PAS CETTE CLASSE

	public static void main(String[] args) {
		// test pour la racine carré si le resultat de la racine carré est un carré parfait on l'affiche
		// sinon on ne l'affiche pas on affiche juste "racine carré (nombre)"
		int nb=25;
		double a=Math.sqrt(nb);
		if(a*a != nb) {
			System.out.println("racine carré de ("+nb+") = racine carré de ("+nb+")");
		}else {
			System.out.println("racine carré de ("+nb+") = "+a);
		}

	}

}