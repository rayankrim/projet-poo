public final class ConstEntiere implements ExpressionArithmetique{
	private final int entier;
	
	public ConstEntiere(int value) {
		this.entier = value;
	}

	public int getEntier() {
		return entier;
	}

	public ExpressionArithmetique simplifier() {
		return this;
	}

 
	public double calculer() {
		return this.getEntier();
	}

}
